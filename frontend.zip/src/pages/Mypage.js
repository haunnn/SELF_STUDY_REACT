function Mypage() {
  return <div>Mypage</div>;
}

export default Mypage;
