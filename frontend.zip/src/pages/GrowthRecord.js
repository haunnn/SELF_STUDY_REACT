function GrowthRecord() {
  return <div>GrowthRecord</div>;
}

export default GrowthRecord;
