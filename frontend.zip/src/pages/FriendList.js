function FriendList() {
  return <div>FriendList</div>;
}

export default FriendList;
