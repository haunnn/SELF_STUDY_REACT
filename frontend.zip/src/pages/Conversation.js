function Conversation() {
  return <div>Conversation</div>;
}

export default Conversation;
