function ConversationLog() {
  return <div>ConversationLog</div>;
}

export default ConversationLog;
